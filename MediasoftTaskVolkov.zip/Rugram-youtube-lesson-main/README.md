# Rugram

Проект для моего youtue канала. В этом курсе мы работаем с React + Redux + Thunk и фейковым API

Ссылка на плейлист
https://www.youtube.com/playlist?list=PLHoG2c7-CfeW-boKFLKru1WAkOdfPFtBt
