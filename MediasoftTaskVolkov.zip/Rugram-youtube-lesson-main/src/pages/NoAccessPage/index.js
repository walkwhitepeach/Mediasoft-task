const NoAccessPage = () => {
    return (
        <div>
            No Access
        </div>
    );
};

export default NoAccessPage;
